#include<stdio.h>
#include<stdlib.h>
typedef struct te{
	int n;
	struct te *p;
}te;


int main()
{
	te *arr = (te *)malloc(sizeof(te)*4);
	
	for(int i=0 ; i <4 ; ++i) {
		printf("%d %p\n", te[i].n, te[i].p);
	}
	return 0;
}